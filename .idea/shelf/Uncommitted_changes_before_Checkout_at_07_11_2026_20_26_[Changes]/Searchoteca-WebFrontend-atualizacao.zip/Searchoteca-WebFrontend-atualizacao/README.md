Searchoteca - Web Frontend
Frontend web do sistema Searchoteca, responsável pela organização do acervo de prateleira de uma biblioteca ou livraria — livros, departamentos, localizações e exemplares — e pela circulação dos exemplares (empréstimos, devoluções, vendas, doações e baixas), através de uma interface construída com Spring Boot + Thymeleaf.
Este módulo não implementa regras de negócio nem persistência: ele consome a API REST do backend do Searchoteca e apresenta os dados em páginas HTML, com o menu adaptado ao perfil de cada usuário.
Índice
Sobre o projeto
Arquitetura
Tecnologias
Pré-requisitos
Configuração
Como executar
Funcionalidades
Estrutura do projeto
Endpoints da aplicação
Sobre o projeto
O Searchoteca é dividido em módulos independentes; este repositório contém apenas a camada web/frontend. A aplicação:
Renderiza páginas server-side com Thymeleaf (sem framework JS de SPA);
Delega toda a leitura e escrita de dados para uma API backend (via `RestClient`);
Organiza o acervo em livros, departamentos, localizações e exemplares, e a circulação em empréstimos e saídas com comprovante.
Arquitetura
```
Navegador  <-->  Searchoteca Web Frontend (Spring MVC + Thymeleaf, porta 8081)  <-->  Searchoteca Backend (API REST, porta 8080)
```
O frontend atua como um cliente HTTP do backend: cada operação da interface (listar, criar, editar, excluir) dispara uma chamada REST correspondente ao serviço `BackendService`, usando um `RestClient` configurado com a URL base do backend.
Tecnologias
Java 21
Spring Boot 4.1.1
Spring Web / Spring MVC
Spring RestClient (consumo da API do backend)
Thymeleaf (templates HTML server-side)
Lombok
Maven (com Maven Wrapper incluso)
Pré-requisitos
JDK 21 instalado
Maven (ou use o `mvnw`/`mvnw.cmd` incluso no projeto)
O backend do Searchoteca rodando e acessível (por padrão em `http://localhost:8080`), já que este frontend depende dele para todas as operações de dados
Configuração
As configurações da aplicação ficam em `Searchoteca Web/frontend/src/main/resources/application.yaml`:
```yaml
server:
  port: 8081

spring:
  application:
    name: frontend

# URL onde o backend (projeto Searchoteca) esta rodando
backend:
  base-url: http://localhost:8080
```
`server.port`: porta em que o frontend será exposto (padrão `8081`).
`backend.base-url`: URL base da API do backend do Searchoteca. Ajuste esse valor caso o backend esteja rodando em outro host/porta.
Como executar
Clone o repositório e acesse a pasta do projeto:
```bash
   git clone https://github.com/GraziPO/Searchoteca-WebFrontend.git
   cd "Searchoteca-WebFrontend/Searchoteca Web/frontend"
   ```
Garanta que o backend do Searchoteca esteja em execução (ou ajuste `backend.base-url` no `application.yaml` para apontar para onde ele está rodando).
Execute a aplicação com o Maven Wrapper:
```bash
   ./mvnw spring-boot:run
   ```
No Windows:
```bash
   mvnw.cmd spring-boot:run
   ```
Acesse no navegador:
```
   http://localhost:8081
   ```
Funcionalidades
O menu lateral mostra só o que o perfil do usuário pode usar. O backend continua sendo quem bloqueia de verdade: uma URL digitada na mão sem permissão responde 403.
Perfil	O que aparece
Root	Tudo, incluindo preço de venda e trilha de auditoria
Administrador de usuários	Usuários
Operador de acervo	Acervo completo: livros, departamentos, localizações, entrada de exemplares, movimentação em lote e etiquetas
Operador de empréstimo	Consulta ao acervo, empréstimos, devoluções, cadastro de alunos, saídas e comprovantes
Aluno	Meus empréstimos e consulta ao acervo
Login e conta
Login em até quatro etapas, na mesma ordem do backend: senha, aceite dos Termos e da Política (se pendente), código MFA por e-mail e troca obrigatória da senha no primeiro acesso.
Esqueci a senha: pedido de código por e-mail e redefinição com o código.
Alterar senha: troca voluntária, pelo link no topo da tela.
Acervo
Livros, departamentos e localizações: listagem com filtro, cadastro, edição e exclusão. A localização escolhe o departamento numa lista.
Preço de venda (opcional): na edição do livro, visível só para o root.
Entrada de exemplares: escolhe o livro, a localização e a quantidade, e gera as etiquetas com código de barras para impressão.
Movimentação em lote: lê várias etiquetas com o leitor de código de barras, confere a quantidade contada e move todas para outra prateleira de uma vez.
Reimpressão de etiquetas a partir dos IDs dos exemplares.
Circulação
Empréstimos: listagem com filtro por status (abertos, atrasados, devolvidos, cancelados), novo empréstimo por RA e IDs dos exemplares, cancelamento e devolução pelo ID do exemplar.
Cadastro de aluno, com senha provisória.
Saídas definitivas (venda, doação e baixa), com comprovante impresso na hora.
Consulta de comprovante pelo código.
Consulta pública
Busca por título, autor, editora ou gênero, paginada, com a disponibilidade e as localizações de cada livro. Funciona sem login.
Relatórios
Trilha de auditoria com filtro por usuário (root).
Estrutura do projeto
```
Searchoteca Web/frontend
├── src/main/java/searchoteca/frontend
│   ├── FrontendApplication.java
│   ├── config/
│   │   ├── RestClientConfig.java         # RestClient com a URL do backend e o token da sessão
│   │   ├── WebMvcConfig.java             # rotas públicas (login, senha, consulta)
│   │   ├── LoginRequiredInterceptor.java # manda para o login quem não tem sessão
│   │   ├── BackendErrorAdvice.java       # erros do backend viram página de erro (401 volta ao login)
│   │   ├── BackendMessages.java          # mensagem do backend para mostrar no formulário
│   │   ├── RoleAccess.java               # o que cada perfil vê no menu
│   │   └── SessionModelAdvice.java       # usuário logado e menu disponíveis em todo template
│   ├── controller/
│   │   ├── LoginController.java          # login em etapas, primeiro acesso, esqueci a senha
│   │   ├── PageController.java           # livros, departamentos, localizações, usuários, alunos
│   │   ├── CopyController.java           # exemplares, etiquetas, movimentação em lote
│   │   ├── CirculationController.java    # empréstimos, devoluções, saídas, comprovantes
│   │   ├── CatalogController.java        # consulta pública
│   │   ├── AccountController.java        # alterar a própria senha
│   │   └── ReportController.java         # auditoria
│   ├── dto/                              # corpos de requisição e respostas do backend
│   ├── model/                            # Book, Department, Location, User, Loan
│   └── service/
│       ├── AuthService.java              # rotas /api/auth e /api/legal
│       ├── BackendService.java           # acervo, exemplares, usuários, auditoria
│       ├── CirculationService.java       # empréstimos, saídas, comprovantes
│       └── CatalogService.java           # /api/public/acervo
├── src/main/resources
│   ├── application.yaml
│   ├── static/css/style.css
│   ├── static/js/                        # filtro de tabelas, contador de leitura, código de barras
│   └── templates/
└── pom.xml
```
Endpoints da aplicação
Método	Rota	Descrição
GET	`/`	Redireciona para a página inicial do perfil (ou para o login)
GET/POST	`/login`	Login
GET/POST	`/primeiro-acesso`	Troca obrigatória da senha inicial
GET/POST	`/esqueci-senha`	Pede o código de redefinição
GET/POST	`/redefinir-senha`	Redefine a senha com o código
GET/POST	`/conta/senha`	Troca voluntária da senha
GET	`/consulta`	Consulta pública ao acervo (sem login)
GET	`/consulta/{isbn}`	Onde encontrar o livro
GET	`/acervo`	Menu do acervo
GET/POST	`/acervo/livros/...`	Livros: listar, incluir, editar, excluir
POST	`/acervo/livros/{isbn}/preco`	Preço de venda (root)
GET/POST	`/acervo/departamentos/...`	Departamentos
GET/POST	`/acervo/localizacoes/...`	Localizações
GET/POST	`/acervo/exemplares/novo`, `/acervo/exemplares`	Entrada de exemplares
GET/POST	`/acervo/exemplares/movimentacao`	Movimentação em lote
GET	`/acervo/exemplares/etiquetas`	Reimpressão de etiquetas
GET	`/emprestimos`	Empréstimos, com filtro por status
GET/POST	`/emprestimos/novo`, `/emprestimos`	Novo empréstimo
POST	`/emprestimos/{id}/cancelar`	Cancela um empréstimo aberto
POST	`/emprestimos/devolucao`	Devolve um exemplar
GET	`/meus-emprestimos`	Empréstimos do aluno logado
GET/POST	`/alunos/novo`, `/alunos`	Cadastro de aluno
GET/POST	`/saidas/nova`, `/saidas`	Venda, doação ou baixa
GET	`/comprovantes`	Consulta de comprovante pelo código
GET/POST	`/usuarios/...`	Usuários: listar, incluir, editar, ativar, desativar
GET	`/relatorios/auditoria`	Trilha de auditoria (root)
Todas essas rotas chamam, internamente, a API REST do backend.
